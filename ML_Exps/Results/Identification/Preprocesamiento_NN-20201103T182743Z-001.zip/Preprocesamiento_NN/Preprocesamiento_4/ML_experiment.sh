#!/usr/bin/bash

#SBATCH -J ML
#SBATCH -D /data3/projects/HERV/Candamil/Procesos_II/positive_database/ML_models
#SBATCH -o out_ML.txt
#SBATCH -e error_ML.txt
#SBATCH -n 20
#SBATCH -N 1

source ~/.bashrc
unset PYTHONPATH
conda activate bioinfo

python3 /data3/projects/HERV/Candamil/Procesos_II/positive_database/ML_models/MLclassifier_experiment7.py
