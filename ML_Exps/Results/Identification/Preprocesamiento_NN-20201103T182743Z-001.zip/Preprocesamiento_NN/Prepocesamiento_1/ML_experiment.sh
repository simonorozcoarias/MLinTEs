#!/usr/bin/bash

#SBATCH -J ML
#SBATCH -D /data3/projects/HERV/Candamil/Procesos_II/positive_database/Machine_Learning/Preprocesamiento_1
#SBATCH -o out_ML_p1.txt
#SBATCH -e error_ML_p1.txt
#SBATCH -n 20
#SBATCH -N 1

source ~/.bashrc
unset PYTHONPATH
conda activate bioinfo

python3 /data3/projects/HERV/Candamil/Procesos_II/positive_database/Machine_Learning/Preprocesamiento_1/MLclassifier_experiment7.py
