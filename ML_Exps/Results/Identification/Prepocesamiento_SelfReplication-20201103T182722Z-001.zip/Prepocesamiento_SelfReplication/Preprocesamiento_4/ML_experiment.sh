#!/usr/bin/bash

#SBATCH -J ML_SR4
#SBATCH -D /data3/projects/HERV/Candamil/Procesos_II/positive_database/Machine_Learning/Preprocesamiento_4_self_replication
#SBATCH -o out_ML_p4_enthalpy.txt
#SBATCH -e error_ML_p4_enthalpy.txt
#SBATCH --partition=long
#SBATCH -n 20
#SBATCH -N 1

source ~/.bashrc
unset PYTHONPATH
conda activate bioinfo

python3 /data3/projects/HERV/Candamil/Procesos_II/positive_database/Machine_Learning/Preprocesamiento_4_self_replication/MLclassifier_experiment7.py
