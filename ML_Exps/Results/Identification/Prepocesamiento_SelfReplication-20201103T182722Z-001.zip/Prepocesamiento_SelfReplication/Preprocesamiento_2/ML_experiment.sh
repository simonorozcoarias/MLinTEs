#!/usr/bin/bash

#SBATCH -J ML2_SR
#SBATCH -D /home/vivian/Paula/ML_Procesos_II/Prepro_SR/Preprocesamiento_2
#SBATCH -o out_ML_prep2_enthalpy.txt
#SBATCH -e error_ML_prep2_enthalpy.txt
#SBATCH --partition=long
#SBATCH -n 20
#SBATCH -N 1

source ~/.bashrc
unset PYTHONPATH
conda activate bioinfo

python3 /home/vivian/Paula/ML_Procesos_II/Prepro_SR/Preprocesamiento_2/MLclassifier_experiment7.py
