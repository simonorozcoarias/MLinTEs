#!/bin/bash
#
#SBATCH --job-name=Exp_6_MLinTEs
#SBATCH --output=Ex6_Sca_DAX.out
#SBATCH -e Ex6_Sca_DAX.err
#SBATCH -D .
#SBATCH -n 20
#SBATCH --partition=highmem
unset PYTHONPATH
source ~/.bashrc;
conda activate ML

python3 ../MLclassifier_experiment6.py ~/Doctorado/databasesForML/finalDatabases/lineages_classification/PGSB/selfReplication/PGSB_0805219_cleaned.fasta_final 24 
