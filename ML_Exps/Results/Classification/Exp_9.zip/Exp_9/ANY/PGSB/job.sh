#!/bin/bash
#
#SBATCH --job-name=Exp9APGSB
#SBATCH -o Exp9.out
#SBATCH -e Exp9.err
#SBATCH -D .
#SBATCH -n 20
#SBATCH -N 1
#SBATCH --partition=workq

module load system/Anaconda3-5.2.0

source activate ML

python3 MLclassifier_experiment9.py /home/rguyot/work/MLenTEs/databases/PGSB_0805219_cleaned.fasta_final.selected 20
