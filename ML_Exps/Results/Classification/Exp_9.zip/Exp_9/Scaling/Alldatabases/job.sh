#!/bin/bash
#
#SBATCH --job-name=Exp9SAlldatabases
#SBATCH -o Exp9.out
#SBATCH -e Exp9.err
#SBATCH -D .
#SBATCH -n 20
#SBATCH -N 1
#SBATCH --partition=workq

module load system/Anaconda3-5.2.0

source activate ML

python3 MLclassifier_experiment9.py /home/rguyot/work/MLenTEs/databases/AllTEs_database.fasta.selected 20
