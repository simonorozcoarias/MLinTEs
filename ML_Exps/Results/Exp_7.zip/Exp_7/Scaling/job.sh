#!/bin/bash
#SBATCH --job-name=Exp7_Scaling
#SBATCH --output=ML_exp7_NB.out
#SBATCH -e ML_exp7_NB.err
#SBATCH -D .
#SBATCH -n 20
#SBATCH -N 1 

unset PYTHONPATH
source ~/.bashrc;
conda activate keras-cpu

python3 MLclassifier_experiment7.py /home/orozco/Doctorado/databasesForML/finalDatabases/lineages_classification/Repbase/NNsFilled/repbase_LTRs_I_3dom.fasta.lineages_final  20
