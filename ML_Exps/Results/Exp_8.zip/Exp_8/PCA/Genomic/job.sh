#!/bin/bash
#
#SBATCH --job-name=Exp8PGenomic
#SBATCH -o Exp8.out
#SBATCH -e Exp8.err
#SBATCH -D .
#SBATCH -n 20
#SBATCH -N 1
#SBATCH --partition=workq

module load system/Anaconda3-5.2.0

source activate ML

python3 MLclassifier_experiment8.py /home/rguyot/work/MLenTEs/databases/TEs_genomic_db.fasta.selected 20
